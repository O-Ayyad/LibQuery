# LibQuery

LibQuery is a quick and lightweight CLI used to query books, scripture, and literature from the command line. Data is stored serverside and fetched from public APIs. 
The C frontend communicates with a local Python/Spark server over TCP.

---

## Building

```bash
# Compile the C frontend
make

# Install Python dependencies
pip install -r requirements.txt
```

Manual build (if not using make):
```bash
gcc -Wall -Wextra -O2 -Isrc/c src/c/main.c src/c/parser.c -o libquery
```

---

## Quick start

```bash
# 1. Start the server (runs in the background)
libquery host

# 2. Download data
libquery download bible genesis
libquery download quran

# 3. Query
libquery bible genesis 1
libquery bible john 3:16
libquery bible romans 1:19-1:21
libquery quran 2:255
libquery quran 2:1-10
```

---

## Reference syntax

```
1           Whole chapter 1
1:5         Chapter 1, verse 5
1-3         Chapters 1 through 3
2-3:19      Chapter 2 through 3:19
1:19-2      1:19 to end of chapter 2
1:19-1:21   Verses 19–21 within chapter 1
# Quran specific
2:1-10      Verses 1-10 within chapter 2
```

---

## All commands

```
libquery <library> <book> [ref]              Query a book
libquery quran [ref]                         Query the Quran by surah:ayah

libquery download bible <book>               Download one Bible book
libquery download bible                      Download entire Bible
libquery download quran                      Download entire Quran

libquery host                                Start the server
libquery ping                                Check server connection
libquery close                               Stop the server
libquery restart                             Restart the server

libquery alias add <library|book> <alias>    Create a short alias
libquery alias ls                            List all aliases
libquery alias rm <alias|all>                Remove alias(es)

libquery target                              Show current target IP
libquery target <IP>                         Route queries to a remote server
libquery target rm                           Reset to localhost

libquery help                                Show this help
```

### Alias examples
```bash
libquery alias add bible b
libquery alias add genesis g
libquery b g 1:1          # resolves to: libquery bible genesis 1:1
```

---

## Data sources

| Library    | API |
|------------|-----|
| Bible (KJV) | https://api.getbible.net/v2 |
| Quran (Arabic + Asad English) | https://alquran.cloud/api |


---

## Project structure

```
libquery/
  libquery.exe / libquery    Compiled binary
  Makefile
  requirements.txt
  src/
    c/
      main.c                 CLI entry point and server client
      parser.c               Reference string parser (1:5, 2-3:19)
      parser_funcs.h         Shared types (Position, Range)
    python/
      config/
        settings.py          Paths, ports, library URLs
      ingestion/
        fetch.py             Downloads raw JSON from external APIs
        ingest.py            Parses JSON to Parquet (via PyArrow)
      local/
        alias_handler.py     Alias add/rm/resolve (runs locally, no server)
        network_handler.py   Target IP get/set (runs locally, no server)
      networking/
        server.py            Async TCP server (asyncio)
        router.py            JSON payload to query engine or ingestion
        registry.py          Known/downloaded book tracking
      query/
        engine.py            Spark query executor
        sql_builder.py       SQL WHERE clause builder
  data/
    raw/                     Downloaded JSON (git-ignored)
    parquet/                 Processed Parquet files (git-ignored)
    serverdata/              Runtime files (admin token, git-ignored)
    userdata/                User config (aliases, target IP, git-ignored)
  hadoop/
    bin/                     Windows winutils (git-ignored, download separately)
```
